

<?php $__env->startSection('title', 'Pemasukan'); ?>

<?php $__env->startSection('link_css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/MenuList/pemasukan.css', 'resources/js/pemasukan/pemasukanImportExcel.js']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="income-page mb-3">

        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session()->has('success')): ?>
            <div class="income-alert income-alert--success mb-4" role="alert">
                <span class="income-alert__icon">
                    <i class="fa-solid fa-circle-check"></i>
                </span>

                <div class="income-alert__content">
                    <strong>Berhasil!</strong>
                    <span><?php echo e(session('success')); ?></span>
                </div>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session()->has('error')): ?>
            <div class="income-alert income-alert--error mb-4" role="alert">
                <span class="income-alert__icon">
                    <i class="fa-solid fa-circle-exclamation"></i>
                </span>

                <div class="income-alert__content">
                    <strong>Terjadi kesalahan</strong>
                    <span><?php echo e(session('error')); ?></span>
                </div>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        
        <section class="income-hero mb-4">

            <div class="income-hero__content">

                <div class="income-eyebrow">
                    <span class="income-eyebrow__dot"></span>
                    MANAJEMEN KEUANGAN
                </div>

                <h1 class="income-hero__title">
                    Kelola <span>Pemasukan</span>
                </h1>

                <p class="income-hero__description">
                    Catat setiap pemasukan yang kamu terima dan
                    kelola riwayat keuanganmu dengan lebih teratur.
                </p>

                <div class="income-benefits">
                    <span>
                        <i class="fa-solid fa-circle-check"></i>
                        Pencatatan teratur
                    </span>

                    <span>
                        <i class="fa-solid fa-circle-check"></i>
                        Mudah dipantau
                    </span>
                </div>

                <div class="income-hero__footer">
                    <a href="<?php echo e(route('pemasukan.create')); ?>" class="income-add-button">

                        <span class="income-add-button__icon">
                            <i class="fa-solid fa-plus"></i>
                        </span>

                        <span class="income-add-button__text">
                            <strong>Tambah Pemasukan</strong>
                            <small>Catat transaksi baru</small>
                        </span>

                        <i class="fa-solid fa-arrow-right income-add-button__arrow"></i>
                    </a>
                </div>

            </div>

            
            <div class="income-hero__art" aria-hidden="true">

                <div class="income-art-orbit"></div>

                <div class="income-art-card">
                    <div class="income-art-card__icon">
                        <i class="fa-solid fa-wallet"></i>
                    </div>

                    <div class="income-art-card__text">
                        <span>FINANCIAL TRACKER</span>
                        <strong>Pemasukan Anda</strong>
                        <small>Setiap transaksi punya catatan.</small>
                    </div>

                    <div class="income-art-card__chart">
                        <i class="fa-solid fa-chart-line"></i>
                    </div>
                </div>

                <div class="income-art-chip">
                    <i class="fa-solid fa-check"></i>
                    Terorganisir dengan baik
                </div>

            </div>

        </section>


        
        
        

        <section class="income-import-card mt-4">

            <div class="income-import-header">
                <div class="income-import-icon">
                    <i class="fa-solid fa-file-excel"></i>
                </div>

                <div class="income-import-heading">
                    <span class="income-import-eyebrow">
                        IMPORT DATA PEMASUKAN
                    </span>

                    <h2>Upload Pemasukan dari Excel</h2>

                    <p>
                        Impor banyak transaksi pemasukan sekaligus.
                        Data akan diperiksa terlebih dahulu sebelum disimpan
                        ke riwayat pemasukanmu.
                    </p>
                </div>
            </div>

            
            <form action="<?php echo e(route('pemasukan.import.preview')); ?>" method="POST" enctype="multipart/form-data"
                class="income-import-form">
                <?php echo csrf_field(); ?>

                <label for="income-excel-file" class="income-import-dropzone" data-income-import-dropzone>
                    <input type="file" id="income-excel-file" name="excel_file" class="income-import-input"
                        accept=".xlsx,.xls,.csv" data-income-import-input required>

                    <span class="income-import-upload-icon">
                        <i class="fa-solid fa-cloud-arrow-up"></i>
                    </span>

                    <strong>Tarik dan lepaskan file Excel di sini</strong>

                    <span class="income-import-description">
                        atau klik area ini untuk memilih file dari perangkatmu.
                    </span>

                    <span class="income-import-formats">
                        XLSX, XLS, atau CSV · Maksimal 5 MB
                    </span>

                    <span class="income-import-filename" data-income-import-filename aria-live="polite">
                        Belum ada file yang dipilih
                    </span>
                </label>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['excel_file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="income-import-validation">
                        <i class="fa-solid fa-circle-exclamation"></i>
                        <?php echo e($message); ?>

                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                <div class="income-import-actions">

                    <a href="<?php echo e(route('pemasukan.import.template')); ?>" class="income-import-template">
                        <i class="fa-solid fa-download"></i>
                        Unduh Template Pemasukan
                    </a>

                    <button type="submit" class="income-import-submit">
                        <i class="fa-solid fa-eye"></i>
                        Baca dan Preview Data
                    </button>

                </div>
            </form>

            <div class="income-import-note">
                <i class="fa-solid fa-shield-halved"></i>

                <span>
                    Fitur ini hanya mengimpor pemasukan. Periksa tanggal,
                    kategori, dan nominal sebelum mengonfirmasi penyimpanan.
                </span>
            </div>

        </section>

        
        
        

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($importPreview)): ?>

            <?php
                $validRows = collect($importPreview)->filter(fn($row) => empty($row['errors']))->count();

                $invalidRows = count($importPreview) - $validRows;
            ?>

            <section class="income-import-preview mt-4">


                <div class="income-import-preview-header d-flex align-items-start justify-content-between gap-3">

                    
                    <div class="income-import-preview-heading">
                        <span class="income-import-eyebrow">
                            PEMERIKSAAN DATA
                        </span>

                        <h2>Preview Pemasukan</h2>

                        <p>
                            Periksa seluruh data pemasukan sebelum disimpan
                            ke database.
                        </p>
                    </div>

                    
                    <div class="income-import-preview-header-actions">

                        <span class="income-import-preview-count">
                            <?php echo e(count($importPreview)); ?> baris
                        </span>

                        <form action="<?php echo e(route('pemasukan.import.cancel')); ?>" method="POST"
                            onsubmit="return confirm('Batalkan preview pemasukan ini? Data preview sementara akan dihapus dan belum ada transaksi yang disimpan.');">
                            <?php echo csrf_field(); ?>

                            <button type="submit" class="income-import-preview-close" title="Batalkan preview"
                                aria-label="Batalkan dan tutup preview pemasukan">
                                <i class="fa-solid fa-xmark"></i>
                            </button>
                        </form>

                    </div>

                </div>


                
                <div class="income-import-summary">

                    <div class="income-import-summary-item">
                        <span>Baris valid</span>

                        <strong class="text-success">
                            <?php echo e($validRows); ?>

                        </strong>
                    </div>

                    <div class="income-import-summary-item">
                        <span>Perlu diperbaiki</span>

                        <strong class="<?php echo e($invalidRows > 0 ? 'text-danger' : 'text-success'); ?>">
                            <?php echo e($invalidRows); ?>

                        </strong>
                    </div>

                </div>

                
                <div class="table-responsive income-import-table-wrap">

                    <table class="table align-middle mb-0 income-import-table">

                        <thead>
                            <tr>
                                <th>Baris</th>
                                <th>Tanggal</th>
                                <th>Transaksi</th>
                                <th>Kategori</th>
                                <th>Sumber Pemasukan</th>
                                <th class="text-end">Nominal</th>
                                <th>Status</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $importPreview; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <tr>
                                    <td>
                                        <?php echo e($row['row_number']); ?>

                                    </td>

                                    <td class="text-nowrap">
                                        <?php echo e($row['tanggal'] ?? '—'); ?>

                                    </td>

                                    <td>
                                        <strong>
                                            <?php echo e($row['label'] ?: '—'); ?>

                                        </strong>

                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($row['deskripsi'])): ?>
                                            <small class="income-import-row-description">
                                                <?php echo e($row['deskripsi']); ?>

                                            </small>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </td>

                                    <td>
                                        <?php echo e($row['kategori'] ?: '—'); ?>

                                    </td>

                                    <td>
                                        <?php echo e($row['sumber_pemasukan'] ?: '—'); ?>

                                    </td>

                                    <td class="text-end text-nowrap">
                                        <?php echo e($row['jumlah'] !== null ? 'Rp ' . number_format($row['jumlah'], 0, ',', '.') : '—'); ?>

                                    </td>

                                    <td>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(empty($row['errors'])): ?>
                                            <span class="income-import-status income-import-status--valid">
                                                <i class="fa-solid fa-circle-check"></i>
                                                Valid
                                            </span>
                                        <?php else: ?>
                                            <span class="income-import-status income-import-status--invalid">
                                                <i class="fa-solid fa-circle-exclamation"></i>
                                                Periksa
                                            </span>

                                            <ul class="income-import-row-errors">
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $row['errors']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                                    <li><?php echo e($error); ?></li>
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                            </ul>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </td>
                                </tr>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </tbody>

                    </table>

                </div>

                
                <div class="income-import-confirm-area">

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($importHasErrors): ?>
                        <p class="income-import-confirm-warning">
                            <i class="fa-solid fa-triangle-exclamation"></i>

                            Masih ada baris tidak valid. Perbaiki file Excel
                            lalu unggah kembali sebelum menyimpan pemasukan.
                        </p>
                    <?php else: ?>
                        <p class="income-import-confirm-help">
                            Semua baris valid. Pastikan jumlah dan kategori
                            pemasukan sudah benar sebelum melanjutkan.
                        </p>

                        <form action="<?php echo e(route('pemasukan.import.confirm')); ?>" method="POST"
                            onsubmit="return confirm('Simpan seluruh pemasukan dari file Excel ini?')">
                            <?php echo csrf_field(); ?>

                            <button type="submit" class="income-import-submit">
                                <i class="fa-solid fa-database"></i>
                                Konfirmasi dan Simpan Pemasukan
                            </button>
                        </form>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                </div>

            </section>

        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>


    </div> 
    <section class="income-list-section">

        
        <div class="income-list-content">
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('pemasukan.komponenindexis');

$__keyOuter = $__key ?? null;

$__key = null;
$__componentSlots = [];

$__key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-4290948062-0', $__key);

$__html = app('livewire')->mount($__name, $__params, $__key, $__componentSlots);

echo $__html;

unset($__html);
unset($__key);
$__key = $__keyOuter;
unset($__keyOuter);
unset($__name);
unset($__params);
unset($__componentSlots);
unset($__split);
?>
        </div>

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\FOLDER-KULIAH\WEB-LOMAB\sistemmanajementkeuanganpribadi\resources\views/pages/Pemasukan/index.blade.php ENDPATH**/ ?>