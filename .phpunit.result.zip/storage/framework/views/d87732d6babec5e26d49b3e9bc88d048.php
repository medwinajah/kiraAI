<div class="kira-chatbot">

    
    <section class="chatbot-launcher-wrap position-fixed bottom-0 end-0 m-3 m-md-4">
        <button
            type="button"
            wire:click="toggleChat"
            class="chatbot-launcher btn d-flex align-items-center gap-3 rounded-pill border-0"
            aria-label="Buka asisten KiraAI"
            aria-controls="kira-chatbot-panel"
            aria-expanded="<?php echo e($OpenFalse ? 'true' : 'false'); ?>"
        >
            <span class="chatbot-launcher-icon">
                <i class="fa-solid fa-robot"></i>
            </span>

            <span class="d-flex flex-column text-start">
                <span class="chatbot-launcher-title">Tanya KiraAI</span>
                <span class="chatbot-launcher-subtitle">Asisten keuanganmu</span>
            </span>

            <span class="chatbot-launcher-sparkle">
                <i class="fa-solid fa-sparkles"></i>
            </span>
        </button>
    </section>

    
    <section
        id="kira-chatbot-panel"
        class="chatbot-panel <?php echo e($OpenFalse ? 'is-open' : ''); ?>"
        aria-hidden="<?php echo e($OpenFalse ? 'false' : 'true'); ?>"
        aria-label="Chat dengan asisten KiraAI"
        role="dialog"
    >

        
        <header class="chatbot-header d-flex align-items-center justify-content-between">

            <div class="d-flex align-items-center gap-3">
                <div class="chatbot-avatar">
                    <i class="fa-solid fa-robot"></i>
                    <span class="chatbot-avatar-status"></span>
                </div>

                <div class="chatbot-header-info">
                    <h6 class="mb-1">KiraAI Assistant</h6>

                    <div class="chatbot-status">
                        <span class="chatbot-status-dot"></span>
                        <span>Asisten Keuangan</span>
                    </div>
                </div>
            </div>

            <button
                type="button"
                wire:click="closeChat"
                class="chatbot-close-btn"
                aria-label="Tutup chat"
            >
                <i class="fa-solid fa-xmark"></i>
            </button>
        </header>

        
        <div
            class="chatbot-messages"
            aria-live="polite"
            aria-relevant="additions text"
        >

            
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(empty($message)): ?>
                <div class="chatbot-welcome">
                    <div class="chatbot-welcome-icon">
                        <i class="fa-solid fa-hand-sparkles"></i>
                    </div>

                    <h6>Halo, selamat datang! 👋</h6>

                    <p>
                        Saya <strong>KiraAI</strong>, asisten keuangan yang siap
                        membantu kamu memahami pemasukan, pengeluaran, dan kondisi
                        keuangan berdasarkan data yang tersedia.
                    </p>

                    <div class="chatbot-welcome-hint">
                        <i class="fa-solid fa-lightbulb me-2"></i>
                        Tanyakan sesuatu tentang keuanganmu.
                    </div>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $message; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <div
                    <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'chat-message-'.e($loop->index).''; ?>wire:key="chat-message-<?php echo e($loop->index); ?>"
                    class="chatbot-message-row <?php echo e($item['role'] === 'user' ? 'is-user' : 'is-assistant'); ?>"
                >

                    
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($item['role'] === 'assistant'): ?>
                        <div class="chatbot-bot-avatar">
                            <i class="fa-solid fa-robot"></i>
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($item['role'] === 'assistant'): ?>
                        <?php
                            $converter = new \League\CommonMark\GithubFlavoredMarkdownConverter([
                                'html_input' => 'strip',
                                'allow_unsafe_links' => false,
                            ]);

                            $renderedHtml = $converter
                                ->convert($item['content'])
                                ->getContent();

                            $safeHtml = \Mews\Purifier\Facades\Purifier::clean($renderedHtml);
                        ?>

                        <div class="chatbot-bubble chatbot-bot chatbot-rich-content">
                            <?php echo $safeHtml; ?>

                        </div>

                    
                    <?php else: ?>
                        <div class="chatbot-bubble chatbot-user">
                            <?php echo e($item['content']); ?>

                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

            
            <div
                wire:loading
                wire:target="sendMessage"
                class="chatbot-message-row is-assistant chatbot-loading-row"
            >
                <div class="chatbot-bot-avatar">
                    <i class="fa-solid fa-robot"></i>
                </div>

                <div class="chatbot-bubble chatbot-bot chatbot-typing">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>

        </div>

        
        <footer class="chatbot-footer">

            <form wire:submit="sendMessage" class="chatbot-form">
                <div class="chatbot-input-wrapper">

                    <input
                        type="text"
                        wire:model="inputMessage"
                        class="chatbot-input"
                        placeholder="Tanyakan sesuatu..."
                        maxlength="1000"
                        autocomplete="off"
                        aria-label="Tulis pesan untuk KiraAI"
                        required
                    >

                    <button
                        type="submit"
                        class="chatbot-send"
                        aria-label="Kirim pesan"
                        wire:loading.attr="disabled"
                        wire:target="sendMessage"
                    >
                        <i
                            class="fa-solid fa-paper-plane"
                            wire:loading.remove
                            wire:target="sendMessage"
                        ></i>

                        <span
                            class="spinner-border spinner-border-sm"
                            wire:loading
                            wire:target="sendMessage"
                            aria-hidden="true"
                        ></span>
                    </button>

                </div>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['inputMessage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="chatbot-error">
                        <i class="fa-solid fa-circle-exclamation me-1"></i>
                        <?php echo e($message); ?>

                    </small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </form>

            <p class="chatbot-footer-note">
                <i class="fa-solid fa-shield-halved me-1"></i>
                Asisten keuangan KiraAI
            </p>

        </footer>

    </section>

</div><?php /**PATH D:\FOLDER-KULIAH\WEB-LOMAB\sistemmanajementkeuanganpribadi\resources\views/livewire/a-i/chatbot-widget.blade.php ENDPATH**/ ?>