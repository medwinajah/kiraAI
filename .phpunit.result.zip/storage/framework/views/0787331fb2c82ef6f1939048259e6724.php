

<?php $__env->startSection('title', 'Laporan Pemasukan'); ?>

<?php $__env->startSection('link_css'); ?>
    
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/LaporanPemasukan/index.css']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="laporan-pemasukan-page container-fluid px-3 px-lg-4 py-4">
        
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
            <div>
                <div class="small text-muted mb-2">
                    <i class="fa-solid fa-house me-1"></i> Dashboard
                    <i class="fa-solid fa-chevron-right mx-2" style="font-size: 10px;"></i> Laporan
                    <i class="fa-solid fa-chevron-right mx-2" style="font-size: 10px;"></i>
                    <span class="text-success fw-semibold">Pemasukan</span>
                </div>
                <h3 class="fw-bold mb-2">Laporan Pemasukan</h3>
                <p class="text-muted mb-0">Pantau dan evaluasi pemasukan berdasarkan periode yang kamu pilih.</p>
            </div>

            <div class="d-flex flex-wrap gap-2">
                
                <a href="<?php echo e(route('laporanpemasukan.export.excel', request()->query())); ?>"
                    class="btn btn-outline-success rounded-3 px-3">
                    <i class="fa-solid fa-file-excel me-2"></i>Ekspor Excel
                </a>
                
                <a href="<?php echo e(route('laporanpemasukan.export.pdf', request()->query())); ?>" target="_blank" rel="noopener"
                    class="btn btn-success rounded-3 px-3">
                    <i class="fa-solid fa-file-pdf me-2"></i>Cetak / PDF
                </a>
            </div>
        </div>

        
        <form method="GET" action="<?php echo e(route('laporanpemasukan.index')); ?>" class="card border-0 shadow-sm rounded-4 mb-4">
            <div class="card-body p-3 p-lg-4">
                <div class="d-flex align-items-center gap-2 mb-3">
                    <div class="laporan-icon-filter"><i class="fa-solid fa-sliders"></i></div>
                    <div>
                        <h6 class="fw-bold mb-1">Filter Laporan</h6>
                        <small class="text-muted">Pilih periode dan kategori pemasukan.</small>
                    </div>
                </div>

                <div class="row g-3">
                    <div class="col-12 col-sm-6 col-lg-3">
                        <label for="periode" class="form-label small fw-semibold">Periode Laporan</label>
                        <select id="periode" name="periode" class="form-select">
                            <option value="harian" <?php if($range['periode'] === 'harian'): echo 'selected'; endif; ?>>Harian</option>
                            <option value="mingguan" <?php if($range['periode'] === 'mingguan'): echo 'selected'; endif; ?>>Mingguan</option>
                            <option value="bulanan" <?php if($range['periode'] === 'bulanan'): echo 'selected'; endif; ?>>Bulanan</option>
                            <option value="tahunan" <?php if($range['periode'] === 'tahunan'): echo 'selected'; endif; ?>>Tahunan</option>
                            <option value="custom" <?php if($range['periode'] === 'custom'): echo 'selected'; endif; ?>>Rentang Tanggal</option>
                        </select>
                    </div>

                    <div class="col-12 col-sm-6 col-lg-3">
                        <label for="tanggalAwal" class="form-label small fw-semibold">Dari Tanggal</label>
                        <input type="date" id="tanggalAwal" name="tanggal_awal" class="form-control"
                            value="<?php echo e($range['tanggalAwal']); ?>">
                    </div>

                    <div class="col-12 col-sm-6 col-lg-3">
                        <label for="tanggalAkhir" class="form-label small fw-semibold">Sampai Tanggal</label>
                        <input type="date" id="tanggalAkhir" name="tanggal_akhir" class="form-control"
                            value="<?php echo e($range['tanggalAkhir']); ?>">
                    </div>

                    <div class="col-12 col-sm-6 col-lg-3">
                        <label for="kategori" class="form-label small fw-semibold">Kategori Pemasukan</label>
                        <select id="kategori" name="kategori" class="form-select">
                            <option value="">Semua Kategori</option>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $kategoriPemasukan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategoriItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <option value="<?php echo e($kategoriItem->id); ?>" <?php if((string) request('kategori') === (string) $kategoriItem->id): echo 'selected'; endif; ?>>
                                    <?php echo e($kategoriItem->nama_kategori); ?>

                                </option>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </select>
                    </div>

                    
                    <input type="hidden" name="search" value="<?php echo e(request('search')); ?>">

                    <div class="col-12 d-flex flex-wrap justify-content-end gap-2 mt-3">
                        
                        <a href="<?php echo e(route('laporanpemasukan.index')); ?>" class="btn btn-light border rounded-3 px-3">
                            <i class="fa-solid fa-rotate-left me-2"></i>Reset
                        </a>
                        <button type="submit" class="btn btn-success rounded-3 px-4">
                            <i class="fa-solid fa-filter me-2"></i>Terapkan Filter
                        </button>
                    </div>
                </div>
            </div>
        </form>

        
        <div class="row g-3 mb-4">
            <div class="col-12 col-sm-6 col-xl-3">
                <div class="card laporan-summary-card border-0 shadow-sm rounded-4 h-100">
                    <div class="card-body p-4">
                        <div class="d-flex justify-content-between align-items-start gap-2">
                            <div>
                                <p class="small text-muted fw-semibold mb-2">Total Pemasukan</p>
                                <h4 class="fw-bold mb-0">Rp <?php echo e(number_format($totalPemasukan, 0, ',', '.')); ?></h4>
                            </div>
                            <div class="laporan-summary-icon bg-success-subtle text-success"><i
                                    class="fa-solid fa-wallet"></i></div>
                        </div>
                        <div class="small text-muted mt-4"><i
                                class="fa-solid fa-calendar-days me-1"></i><?php echo e($range['labelPeriode']); ?></div>
                    </div>
                </div>
            </div>

            <div class="col-12 col-sm-6 col-xl-3">
                <div class="card laporan-summary-card border-0 shadow-sm rounded-4 h-100">
                    <div class="card-body p-4">
                        <div class="d-flex justify-content-between align-items-start gap-2">
                            <div>
                                <p class="small text-muted fw-semibold mb-2">Jumlah Transaksi</p>
                                <h4 class="fw-bold mb-0"><?php echo e(number_format($jumlahTransaksi, 0, ',', '.')); ?> <span
                                        class="fs-6 fw-normal text-muted">transaksi</span></h4>
                            </div>
                            <div class="laporan-summary-icon bg-primary-subtle text-primary"><i
                                    class="fa-solid fa-receipt"></i></div>
                        </div>
                        <div class="small text-muted mt-4">Sesuai periode dan kategori terpilih</div>
                    </div>
                </div>
            </div>

            <div class="col-12 col-sm-6 col-xl-3">
                <div class="card laporan-summary-card border-0 shadow-sm rounded-4 h-100">
                    <div class="card-body p-4">
                        <div class="d-flex justify-content-between align-items-start gap-2">
                            <div>
                                <p class="small text-muted fw-semibold mb-2">Rata-rata Pemasukan</p>
                                <h4 class="fw-bold mb-0">Rp <?php echo e(number_format($rataRataPemasukan, 0, ',', '.')); ?></h4>
                            </div>
                            <div class="laporan-summary-icon bg-info-subtle text-info"><i
                                    class="fa-solid fa-chart-line"></i></div>
                        </div>
                        <div class="small text-muted mt-4">Rata-rata per transaksi</div>
                    </div>
                </div>
            </div>

            <div class="col-12 col-sm-6 col-xl-3">
                <div class="card laporan-summary-card border-0 shadow-sm rounded-4 h-100">
                    <div class="card-body p-4">
                        <div class="d-flex justify-content-between align-items-start gap-2">
                            <div>
                                <p class="small text-muted fw-semibold mb-2">Pemasukan Terbesar</p>
                                <h4 class="fw-bold mb-0">Rp <?php echo e(number_format($pemasukanTerbesar, 0, ',', '.')); ?></h4>
                            </div>
                            <div class="laporan-summary-icon bg-warning-subtle text-warning"><i
                                    class="fa-solid fa-arrow-trend-up"></i></div>
                        </div>
                        <div class="small text-muted mt-4">Nilai transaksi tertinggi</div>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="row g-3 mb-4">
            <div class="col-12 col-xl-8">
                <div class="card border-0 shadow-sm rounded-4 h-100">
                    <div class="card-body p-3 p-lg-4">
                        <div class="d-flex flex-wrap justify-content-between align-items-start gap-3 mb-4">
                            <div>
                                <h6 class="fw-bold mb-1">Tren Pemasukan</h6>
                                <p class="small text-muted mb-0">Pengelompokan otomatis berdasarkan periode laporan.</p>
                            </div>
                            <span class="badge rounded-pill bg-success-subtle text-success px-3 py-2">
                                <i
                                    class="fa-solid fa-chart-column me-1"></i><?php echo e(ucfirst($range['periode'] === 'custom' ? 'rentang tanggal' : $range['periode'])); ?>

                            </span>
                        </div>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(collect($grafikPemasukan)->sum('jumlah') > 0): ?>
                            
                            <div class="laporan-chart-scroll">
                                <div class="laporan-chart-grid" style="--jumlah-kolom: <?php echo e(count($grafikPemasukan)); ?>;">
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $grafikPemasukan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                        <div class="laporan-chart-column"
                                            title="<?php echo e($item['label']); ?>: Rp <?php echo e(number_format($item['jumlah'], 0, ',', '.')); ?>">
                                            <span
                                                class="small text-muted mb-2"><?php echo e(number_format($item['jumlah'] / 1000000, 2, ',', '.')); ?>

                                                jt</span>
                                            <div class="laporan-chart-track">
                                                <div class="laporan-chart-bar" style="height: <?php echo e($item['tinggi']); ?>%;">
                                                </div>
                                            </div>
                                            <span class="small text-muted mt-2 text-center"><?php echo e($item['label']); ?></span>
                                        </div>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                </div>
                            </div>
                        <?php else: ?>
                            
                            <div class="laporan-empty-chart text-center py-5">
                                <i class="fa-solid fa-chart-column fs-1 text-success mb-3"></i>
                                <p class="fw-semibold mb-1">Belum ada data grafik</p>
                                <span class="small text-muted">Tidak ditemukan pemasukan untuk periode dan kategori
                                    ini.</span>
                            </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                        <div class="d-flex align-items-center gap-2 small text-muted mt-4">
                            <span class="laporan-chart-legend"></span>Total pemasukan per kelompok waktu
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="col-12 col-xl-4">
                <div class="card border-0 shadow-sm rounded-4 h-100">
                    <div class="card-body p-3 p-lg-4">
                        <h6 class="fw-bold mb-1">Informasi Laporan</h6>
                        <p class="small text-muted mb-4">Ringkasan dari transaksi yang sesuai dengan filter.</p>

                        <div class="laporan-info-item">
                            <div class="laporan-info-icon"><i class="fa-solid fa-calendar-check"></i></div>
                            <div><small class="text-muted d-block">Periode</small><span
                                    class="fw-semibold"><?php echo e($range['labelPeriode']); ?></span></div>
                        </div>
                        <div class="laporan-info-item">
                            <div class="laporan-info-icon"><i class="fa-solid fa-layer-group"></i></div>
                            <div><small class="text-muted d-block">Kategori teratas</small><span
                                    class="fw-semibold"><?php echo e($kategoriTeratas); ?></span></div>
                        </div>
                        <div class="laporan-info-item mb-0">
                            <div class="laporan-info-icon"><i class="fa-solid fa-clock-rotate-left"></i></div>
                            <div>
                                <small class="text-muted d-block">Transaksi terakhir</small>
                                <span
                                    class="fw-semibold"><?php echo e($transaksiTerakhir?->tanggal_pemasukan?->format('d/m/Y H:i') ?? 'Belum ada transaksi'); ?></span>
                            </div>
                        </div>

                        <hr class="my-4">
                        <div class="p-3 rounded-3 bg-success-subtle">
                            <div class="d-flex align-items-start gap-2">
                                <i class="fa-solid fa-lightbulb text-success mt-1"></i>
                                <div>
                                    <p class="fw-semibold text-success mb-1">Tips Keuangan</p>
                                    <p class="small mb-0 text-dark">Catat transaksi secara rutin agar laporan pemasukan dan
                                        evaluasi keuangan tetap akurat.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="card border-0 shadow-sm rounded-4">
            <div class="card-body p-0">
                <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 p-3 p-lg-4">
                    <div>
                        <h6 class="fw-bold mb-1">Detail Transaksi Pemasukan</h6>
                        <p class="small text-muted mb-0">Daftar transaksi sesuai periode, kategori, dan kata pencarian.</p>
                    </div>

                    
                    <form method="GET" action="<?php echo e(route('laporanpemasukan.index')); ?>"
                        class="input-group laporan-search">
                        <input type="hidden" name="periode" value="<?php echo e($range['periode']); ?>">
                        <input type="hidden" name="tanggal_awal" value="<?php echo e($range['tanggalAwal']); ?>">
                        <input type="hidden" name="tanggal_akhir" value="<?php echo e($range['tanggalAkhir']); ?>">
                        <input type="hidden" name="kategori" value="<?php echo e(request('kategori')); ?>">
                        <span class="input-group-text bg-white"><i
                                class="fa-solid fa-magnifying-glass text-muted"></i></span>
                        <input type="search" name="search" class="form-control border-start-0 ps-0"
                            placeholder="Cari transaksi..." aria-label="Cari transaksi" value="<?php echo e(request('search')); ?>">
                        <button class="btn btn-outline-success" type="submit">Cari</button>
                    </form>
                </div>

                <div class="table-responsive">
                    <table class="table align-middle mb-0 laporan-table">
                        <thead>
                            <tr>
                                <th class="ps-4">No.</th>
                                <th>Tanggal</th>
                                <th>Nama Pemasukan</th>
                                <th>Kategori</th>
                                <th>Sumber</th>
                                <th>Deskripsi</th>
                                <th class="text-end pe-4">Jumlah</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $laporan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <tr>
                                    <td class="ps-4 text-muted"><?php echo e($laporan->firstItem() + $index); ?></td>
                                    <td><span
                                            class="text-nowrap"><?php echo e($item->tanggal_pemasukan?->format('d/m/Y H:i') ?? '-'); ?></span>
                                    </td>
                                    <td>
                                        <div class="d-flex align-items-center gap-2">
                                            <div class="laporan-transaction-icon"><i class="fa-solid fa-arrow-down"></i>
                                            </div>
                                            <span class="fw-semibold"><?php echo e($item->label); ?></span>
                                        </div>
                                    </td>
                                    <td><span
                                            class="badge rounded-pill bg-light text-dark border px-3 py-2"><?php echo e($item->Kategori?->nama_kategori ?? 'Tanpa Kategori'); ?></span>
                                    </td>
                                    <td class="text-muted"><?php echo e($item->sumber_pemasukan ?: '-'); ?></td>
                                    <td class="text-muted laporan-description"><?php echo e($item->deskripsi_pemasukan ?: '-'); ?>

                                    </td>
                                    <td class="text-end pe-4"><span class="fw-bold text-success text-nowrap">+ Rp
                                            <?php echo e(number_format($item->jumlah_pemasukan, 0, ',', '.')); ?></span></td>
                                </tr>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                
                                <tr>
                                    <td colspan="7" class="text-center py-5">
                                        <!-- Wrapper d-flex diletakkan di dalam td -->
                                        <div class="d-flex flex-column align-items-center justify-content-center">
                                            <i class="fa-solid fa-folder-open fs-1 text-muted mb-3"></i>
                                            <p class="fw-semibold mb-1">Belum ada data pemasukan</p>
                                            <span class="text-muted small">Coba ubah periode, kategori, atau kata
                                                pencarian.</span>
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <div
                    class="d-flex flex-column flex-sm-row justify-content-between align-items-sm-center gap-3 px-3 px-lg-4 py-3 border-top">
                    <small class="text-muted">
                        Menampilkan <?php echo e($laporan->firstItem() ?? 0); ?>–<?php echo e($laporan->lastItem() ?? 0); ?> dari
                        <?php echo e($laporan->total()); ?> transaksi
                    </small>
                    
                    <div><?php echo e($laporan->onEachSide(1)->links('pagination::bootstrap-5')); ?></div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\FOLDER-KULIAH\WEB-LOMAB\sistemmanajementkeuanganpribadi\resources\views/pages/LaporanPemasukan/index.blade.php ENDPATH**/ ?>