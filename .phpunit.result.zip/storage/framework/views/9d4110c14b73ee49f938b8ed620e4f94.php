
     
                    <section  wire:ignore.self class="mb-1 col-lg-6 col-sm-12">
                        <label for="jumlah_pengeluaran" class="form-label small fw-semibold">Jumlah Pengeluaran <sup class="text-danger fs-6">*</sup></label>
                        <div class=" border rounded-3 p-0 d-flex align-items-center <?php $__errorArgs = ['jumlah_pengeluaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            border-danger
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <span class="border-0 d-flex gap-2 p-2">
                             <i class="fa-solid fa-bookmark"></i>         
                        </span>
                        <input wire:ignore type="number" wire:model.live.debounce.300ms="jumlah_pengeluaran" 
                        name="jumlah_pengeluaran" 
                        value="<?php echo e($jumlah_pengeluaran); ?>"
                        class="form-control p-2 border-0 w-100 focus-ring focus-ring-light" placeholder="1000000" id="jumlah_pengeluaran">
                        </div>
                        
                        <p class="mt-1 mb-0 fw-semibold">Rp. <?php echo e(number_format((float)$jumlah_pengeluaran,0,',','.')); ?> </p>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['jumlah_pengeluaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="small text-danger d-block"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </section>

<?php /**PATH D:\FOLDER-KULIAH\WEB-LOMAB\sistemmanajementkeuanganpribadi\resources\views/livewire/pengeluaran/partials/formnumber.blade.php ENDPATH**/ ?>