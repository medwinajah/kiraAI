<div class="dashboard-analytics" data-dashboard-grafik>

    
    <script type="application/json" data-dashboard-chart-data><?php echo json_encode($chartData, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT); ?></script>


    
    
    

    <section class="dashboard-filter-toolbar mb-3">

        <div class="dashboard-filter-information">

            <span class="dashboard-filter-eyebrow">
                <i class="fa-solid fa-sliders me-1"></i>
                FILTER ANALISIS
            </span>

            <h6 class="dashboard-filter-title">
                Periode Keuangan
            </h6>

            <p class="dashboard-filter-description">
                <?php echo e($keteranganPeriode); ?>

            </p>

        </div>


        <div class="dashboard-filter-actions">

            

            <div class="dashboard-filter-control dashboard-filter-control-period">

                <label
                    for="dashboard-periode"
                    class="dashboard-filter-label"
                >
                    Periode
                </label>

                <div class="dashboard-filter-select-wrap">

                    <i class="fa-regular fa-calendar"></i>

                    <select
                        id="dashboard-periode"
                        class="form-select dashboard-period-select"
                        wire:model.live="periode"
                        aria-label="Pilih periode grafik keuangan"
                    >
                        <option value="harian">Harian</option>
                        <option value="mingguan">Mingguan</option>
                        <option value="bulanan">Bulanan</option>
                        <option value="tahunan">Tahunan</option>
                        <option value="rentang">Rentang tanggal</option>
                    </select>

                    <i class="fa-solid fa-chevron-down dashboard-filter-chevron"></i>

                </div>

            </div>


            

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($periode === 'rentang'): ?>

                <div class="dashboard-filter-control dashboard-filter-control-date">

                    <label
                        for="dashboard-tanggal-mulai"
                        class="dashboard-filter-label"
                    >
                        Dari tanggal
                    </label>

                    <input
                        type="date"
                        id="dashboard-tanggal-mulai"
                        class="form-control dashboard-filter-date-input"
                        wire:model.live="tanggalMulai"
                        max="<?php echo e(now()->toDateString()); ?>"
                        aria-label="Tanggal mulai grafik"
                    >

                </div>


                <div class="dashboard-filter-control dashboard-filter-control-date">

                    <label
                        for="dashboard-tanggal-sampai"
                        class="dashboard-filter-label"
                    >
                        Sampai tanggal
                    </label>

                    <input
                        type="date"
                        id="dashboard-tanggal-sampai"
                        class="form-control dashboard-filter-date-input"
                        wire:model.live="tanggalSampai"
                        min="<?php echo e($tanggalMulai ?: ''); ?>"
                        max="<?php echo e(now()->toDateString()); ?>"
                        aria-label="Tanggal akhir grafik"
                    >

                </div>

            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>


            

            <button
                type="button"
                class="btn dashboard-filter-reset"
                wire:click="resetFilter"
                wire:loading.attr="disabled"
                wire:target="resetFilter"
                title="Reset filter ke periode mingguan"
            >

                <span wire:loading.remove wire:target="resetFilter">
                    <i class="fa-solid fa-rotate-left me-2"></i>
                    Reset
                </span>

                <span wire:loading wire:target="resetFilter">
                    <span class="spinner-border spinner-border-sm me-1"></span>
                    Memuat...
                </span>

            </button>

        </div>

    </section>


    
    
    

    <section class="dashboard-chart-panel dashboard-chart-panel-main mb-3">

        <div class="dashboard-panel-header">

            <div>

                <span class="dashboard-panel-kicker">
                    RINGKASAN <?php echo e(strtoupper($labelPeriode)); ?>

                </span>

                <h6 class="dashboard-panel-title">
                    Pemasukan vs. Pengeluaran
                </h6>

                <p class="dashboard-panel-description">
                    Bandingkan nominal uang masuk dan uang keluar.
                    <?php echo e($keteranganPeriode); ?>.
                </p>

            </div>

            <div class="dashboard-panel-icon dashboard-panel-icon-income">
                <i class="fa-solid fa-chart-area"></i>
            </div>

        </div>


        <div
            class="dashboard-chart-canvas-wrap dashboard-chart-canvas-main"
            wire:ignore
        >

            <canvas
                data-dashboard-chart="perbandingan"
                role="img"
                aria-label="Grafik area perbandingan pemasukan dan pengeluaran pada periode <?php echo e($labelPeriode); ?>"
            ></canvas>

        </div>


        <div class="dashboard-chart-footnote">

            <i class="fa-solid fa-circle-info me-2"></i>

            <span>
                Data berdasarkan tanggal transaksi pada periode
                <?php echo e(strtolower($labelPeriode)); ?> yang dipilih.
            </span>

        </div>

    </section>


    
    
    

    <div class="row g-3 dashboard-category-grid">


        

        <div class="col-12 col-xl-6">

            <section class="dashboard-chart-panel h-100">

                <div class="dashboard-panel-header">

                    <div>

                        <span class="dashboard-panel-kicker">
                            SUMBER PEMASUKAN
                        </span>

                        <h6 class="dashboard-panel-title">
                            Kategori Pemasukan Teratas
                        </h6>

                        <p class="dashboard-panel-description">
                            Lima kategori dengan jumlah transaksi terbanyak
                            pada periode terpilih.
                        </p>

                    </div>

                    <div class="dashboard-panel-icon dashboard-panel-icon-income">
                        <i class="fa-solid fa-arrow-trend-up"></i>
                    </div>

                </div>


                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($kategoriPemasukan->isNotEmpty()): ?>

                    <div
                        class="dashboard-chart-canvas-wrap dashboard-chart-canvas-category"
                        wire:ignore
                    >

                        <canvas
                            data-dashboard-chart="kategori-pemasukan"
                            role="img"
                            aria-label="Grafik kategori pemasukan pada periode terpilih"
                        ></canvas>

                    </div>

                <?php else: ?>

                    <div class="dashboard-chart-empty">

                        <div class="dashboard-empty-icon">
                            <i class="fa-solid fa-chart-bar"></i>
                        </div>

                        <h6>Belum ada data pemasukan</h6>

                        <p>
                            Tidak ditemukan transaksi pemasukan pada periode
                            yang dipilih.
                        </p>

                    </div>

                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>


                <div class="dashboard-chart-footnote">

                    <i class="fa-solid fa-circle-info me-2"></i>

                    <span>
                        Berdasarkan periode <?php echo e(strtolower($labelPeriode)); ?>.
                    </span>

                </div>

            </section>

        </div>


        

        <div class="col-12 col-xl-6">

            <section class="dashboard-chart-panel h-100">

                <div class="dashboard-panel-header">

                    <div>

                        <span class="dashboard-panel-kicker">
                            ALOKASI PENGELUARAN
                        </span>

                        <h6 class="dashboard-panel-title">
                            Kategori Pengeluaran Teratas
                        </h6>

                        <p class="dashboard-panel-description">
                            Lima kategori dengan jumlah transaksi terbanyak
                            pada periode terpilih.
                        </p>

                    </div>

                    <div class="dashboard-panel-icon dashboard-panel-icon-expense">
                        <i class="fa-solid fa-arrow-trend-down"></i>
                    </div>

                </div>


                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($kategoriPengeluaran->isNotEmpty()): ?>

                    <div
                        class="dashboard-chart-canvas-wrap dashboard-chart-canvas-category"
                        wire:ignore
                    >

                        <canvas
                            data-dashboard-chart="kategori-pengeluaran"
                            role="img"
                            aria-label="Grafik kategori pengeluaran pada periode terpilih"
                        ></canvas>

                    </div>

                <?php else: ?>

                    <div class="dashboard-chart-empty">

                        <div class="dashboard-empty-icon dashboard-empty-icon-expense">
                            <i class="fa-solid fa-chart-bar"></i>
                        </div>

                        <h6>Belum ada data pengeluaran</h6>

                        <p>
                            Tidak ditemukan transaksi pengeluaran pada periode
                            yang dipilih.
                        </p>

                    </div>

                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>


                <div class="dashboard-chart-footnote">

                    <i class="fa-solid fa-circle-info me-2"></i>

                    <span>
                        Berdasarkan periode <?php echo e(strtolower($labelPeriode)); ?>.
                    </span>

                </div>

            </section>

        </div>

    </div>


    
    
    

   



<section class="dashboard-transaction-panel mt-3">

    <div class="dashboard-panel-header dashboard-transaction-header">

        <div>
            <span class="dashboard-panel-kicker">
                RIWAYAT AKTIVITAS
            </span>

            <h6 class="dashboard-panel-title">
                Transaksi Terbaru
            </h6>

            <p class="dashboard-panel-description">
                Enam transaksi terakhir dari seluruh riwayat keuanganmu.
            </p>
        </div>

        <div class="dashboard-transactions-count">
            <i class="fa-solid fa-receipt me-2"></i>
            <?php echo e($transaksiTerbaru->count()); ?> transaksi
        </div>

    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($transaksiTerbaru->isEmpty()): ?>

        <div class="dashboard-transaction-empty">

            <div class="dashboard-empty-icon">
                <i class="fa-regular fa-calendar-check"></i>
            </div>

            <h6>Belum ada transaksi</h6>

            <p>
                Transaksi pemasukan dan pengeluaranmu akan muncul
                di bagian ini setelah berhasil dicatat.
            </p>

        </div>

    <?php else: ?>

        <div class="table-responsive dashboard-table-wrap">

            <table class="table align-middle dashboard-transaction-table mb-0">

                <thead>
                    <tr>
                        <th scope="col">Tanggal</th>
                        <th scope="col">Transaksi</th>
                        <th scope="col">Kategori</th>
                        <th scope="col">Jenis</th>
                        <th scope="col" class="text-end">Nominal</th>
                    </tr>
                </thead>

                <tbody>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $transaksiTerbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaksi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>

                        <tr <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'transaksi-terbaru-'.e($transaksi['id']).''; ?>wire:key="transaksi-terbaru-<?php echo e($transaksi['id']); ?>">

                            

                            <td>
                                <span class="dashboard-transaction-time">
                                    <?php echo e($transaksi['tanggal']->format('d/m/Y')); ?>

                                    <br>
                                    <?php echo e($transaksi['tanggal']->format('H:i')); ?>

                                </span>
                            </td>

                            

                            <td>
                                <div class="dashboard-transaction-name">
                                    <?php echo e($transaksi['label']); ?>

                                </div>

                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($transaksi['deskripsi'])): ?>
                                    <div class="dashboard-transaction-description">
                                        <?php echo e($transaksi['deskripsi']); ?>

                                    </div>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </td>

                            

                            <td>
                                <span class="dashboard-category-pill">
                                    <?php echo e($transaksi['kategori']); ?>

                                </span>
                            </td>

                            

                            <td>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($transaksi['jenis'] === 'Pemasukan'): ?>

                                    <span class="dashboard-type-pill dashboard-type-income">
                                        <i class="fa-solid fa-arrow-down me-1"></i>
                                        Pemasukan
                                    </span>

                                <?php else: ?>

                                    <span class="dashboard-type-pill dashboard-type-expense">
                                        <i class="fa-solid fa-arrow-up me-1"></i>
                                        Pengeluaran
                                    </span>

                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </td>

                            

                            <td class="text-end">

                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($transaksi['jenis'] === 'Pemasukan'): ?>

                                    <span class="dashboard-transaction-amount dashboard-amount-income">
                                        + Rp <?php echo e(number_format($transaksi['jumlah'], 0, ',', '.')); ?>

                                    </span>

                                <?php else: ?>

                                    <span class="dashboard-transaction-amount dashboard-amount-expense">
                                        − Rp <?php echo e(number_format($transaksi['jumlah'], 0, ',', '.')); ?>

                                    </span>

                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                            </td>

                        </tr>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

                </tbody>

            </table>

        </div>

    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

</section>
</div><?php /**PATH D:\FOLDER-KULIAH\WEB-LOMAB\sistemmanajementkeuanganpribadi\resources\views/livewire/dashboard/grafik.blade.php ENDPATH**/ ?>