<div>
    
    <button type="button" class="btn btn-success d-flex py-3 rounded-4 gap-2 align-items-center" data-scan-button>
        <i class="fa-solid fa-camera"></i>
        <span class="fw-semibold">Scan Nota</span>
    </button>

    
    <div class="modal fade" data-scan-modal tabindex="-1" aria-labelledby="judulScanNota" aria-hidden="true"
        wire:ignore.self>
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content rounded-4 overflow-hidden">

                <div class="modal-header">
                    <h5 class="modal-title fw-bold" id="judulScanNota">
                        <i class="fa-solid fa-camera text-success me-2"></i>
                        spanScan Nota Pengeluaran
                    </h5>

                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
                </div>

                <div class="modal-body">
                    <p class="small text-secondary">
                        Gunakan kamera perangkat dan posisikan nota
                        agar nama barang serta harganya terlihat jelas.
                        Pada HP, kamera belakang akan diprioritaskan jika tersedia
                    </p>

                    
                    <div class="bg-dark rounded-4 overflow-hidden" wire:ignore>
                        <video data-scan-video class="w-100 d-block" autoplay muted playsinline
                            style="max-height: 55vh; object-fit: contain;"></video>

                        <canvas data-scan-canvas class="d-none"></canvas>
                    </div>

                    <div class="small mt-3" data-scan-status role="status" aria-live="polite" wire:ignore>
                        Menyiapkan kamera...
                    </div>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['fotoNota'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger small mt-3 mb-0">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($errorMessage): ?>
                        <div class="alert alert-danger small mt-3 mb-0">
                            <?php echo e($errorMessage); ?>

                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($errors->any()): ?>
                        <div class="alert alert-danger small mt-3">
                            Ada data yang belum valid.
                            Periksa kembali nama barang, harga, kategori, dan tanggal.
                            <?php echo e($errors->first()); ?>

                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    <div wire:loading wire:target="scanNota" class="alert alert-info small mt-3 mb-0">
                        <span class="spinner-border spinner-border-sm me-2" aria-hidden="true"></span>
                        AI sedang membaca nota...
                    </div>

                    
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(count($items) > 0): ?>
                        <div class="mt-4">
                            <h6 class="fw-bold">Periksa Hasil Scan</h6>

                            <p class="small text-secondary">
                                Toko:
                                <?php echo e($merchant ?: 'Tidak terbaca'); ?>

                                <br>
                                Periksa semua informasi sebelum menyimpan.
                            </p>
                            
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                    <div class="border rounded-4 p-3 mb-3"
                                        <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'scan-nota-item-'.e($index).''; ?>wire:key="scan-nota-item-<?php echo e($index); ?>">
                                        <div class="d-flex justify-content-between align-items-center mb-3">
                                            <strong>Barang <?php echo e($index + 1); ?></strong>

                                            <button type="button" class="btn btn-sm btn-outline-danger rounded-3"
                                                wire:click="removeItem(<?php echo e($index); ?>)">
                                                Hapus
                                            </button>
                                        </div>

                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($item['certainty'] === 'uncertain'): ?>
                                            <div class="alert alert-warning small py-2">
                                                Informasi ini perlu diperiksa kembali.
                                            </div>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                        <div class="mb-3">
                                            <label class="form-label small fw-semibold">
                                                Nama barang
                                            </label>

                                            <input type="text" class="form-control"
                                                wire:model="items.<?php echo e($index); ?>.label" required maxlength="255">
                                        </div>

                                        <div class="mb-3">
                                            <label class="form-label small fw-semibold">
                                                Kategori pengeluaran
                                            </label>

                                            <select class="form-select" wire:model="items.<?php echo e($index); ?>.kategori"
                                                required>
                                                <option value="">
                                                    Pilih kategori
                                                </option>

                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $kategori_pengeluaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                                    <option value="<?php echo e($kategori->id); ?>">
                                                        <?php echo e($kategori->nama_kategori ?? ($kategori->nama_ketegori ?? 'Kategori #' . $kategori->id)); ?>

                                                    </option>
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                                    <option value="" disabled selected>
                                                        -- Kategori belum ada, silahkan buat kategori terlebih dahulu --
                                                    </option>
                                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            </select>
                                        </div>

                                        <div class="mb-3">
                                            <label class="form-label small fw-semibold">
                                                Harga barang (Rp)
                                            </label>

                                            <input type="number" class="form-control"
                                                wire:model="items.<?php echo e($index); ?>.amount" min="1000"
                                                step="1" required>
                                        </div>

                                        <div class="mb-3">
                                            <label class="form-label small fw-semibold">
                                                Tanggal pengeluaran
                                            </label>

                                            <input type="date" class="form-control"
                                                wire:model="items.<?php echo e($index); ?>.tanggal_pengeluaran" required>
                                        </div>

                                        <div>
                                            <label class="form-label small fw-semibold">
                                                Deskripsi
                                            </label>

                                            <textarea class="form-control" wire:model="items.<?php echo e($index); ?>.deskripsi_pengeluaran" rows="2"
                                                placeholder="Opsional"></textarea>
                                        </div>
                                    </div>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-success rounded-3" data-scan-capture>
                        <i class="fa-solid fa-wand-magic-sparkles me-1"></i>
                        Baca Nota dengan AI
                    </button>

                    <button type="button" class="btn btn-outline-secondary rounded-3 d-none" data-scan-again>
                        Scan Ulang
                    </button>

                    <button type="button" class="btn btn-light border rounded-3" data-bs-dismiss="modal">
                        Tutup
                    </button>
                </div>
                
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(count($items) > 0): ?>
                    <section class="mb-2 px-2 py-2 text-right">
                        <button type="button" class="btn btn-success rounded-3 w-100" wire:click="simpanSemua"
                            wire:loading.attr="disabled" wire:target="simpanSemua">
                            <span wire:loading.remove wire:target="simpanSemua">
                                <i class="fa-solid fa-floppy-disk me-1"></i>
                                Simpan Semua Pengeluaran (<?php echo e(count($items)); ?>)
                            </span>

                            <span wire:loading wire:target="simpanSemua">
                                <span class="spinner-border spinner-border-sm me-1" aria-hidden="true"></span>
                                Menyimpan...
                            </span>
                        </button>
                    </section>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                

            </div>
        </div>
    </div>
</div>

    <?php
        $__scriptKey = '1983955455-0';
        ob_start();
    ?>
    <script>
        const root = $wire.$el;

        const tombolScan = root.querySelector('[data-scan-button]');
        const modalElement = root.querySelector('[data-scan-modal]');
        const video = root.querySelector('[data-scan-video]');
        const canvas = root.querySelector('[data-scan-canvas]');
        const status = root.querySelector('[data-scan-status]');
        const tombolAmbil = root.querySelector('[data-scan-capture]');
        const tombolUlang = root.querySelector('[data-scan-again]');

        const modal = bootstrap.Modal.getOrCreateInstance(modalElement);
        // const mediaHP = window.matchMedia('(max-width: 767.98px)');

        let stream = null;
        let sedangUpload = false;

        // function aturTombolScan() {
        //     tombolScan.disabled = !mediaHP.matches;
        //     tombolScan.title = mediaHP.matches ?
        //         'Buka kamera untuk scan nota' :
        //         'Scan Nota tersedia melalui HP';

        //     if (!mediaHP.matches && modalElement.classList.contains('show')) {
        //         modal.hide();
        //     }
        // }

        function hentikanKamera() {
            if (stream) {
                stream.getTracks().forEach(track => track.stop());
                stream = null;
            }

            video.pause();
            video.srcObject = null;
        }

        async function mulaiKamera() {
            if (stream) return;

            if (!navigator.mediaDevices?.getUserMedia) {
                status.textContent =
                    'Kamera membutuhkan browser yang mendukung akses kamera melalui HTTPS atau localhost.';
                return;
            }

            status.textContent = 'Meminta izin kamera...';

            try {
                stream = await navigator.mediaDevices.getUserMedia({
                    audio: false,
                    video: {
                        facingMode: {
                            ideal: 'environment'
                        },
                        width: {
                            ideal: 1280
                        },
                        height: {
                            ideal: 720
                        }
                    }
                });

                video.srcObject = stream;
                await video.play();

                tombolAmbil.disabled = false;
                status.textContent =
                    'Kamera siap. Arahkan ke nota dan pastikan tulisannya jelas.';
            } catch (error) {
                hentikanKamera();

                status.textContent = error.name === 'NotAllowedError' ?
                    'Akses kamera ditolak. Izinkan kamera pada browser.' :
                    'Kamera gagal dibuka. Periksa izin kamera dan HTTPS.';

                console.error('Kesalahan kamera:', error);
            }
        }

        // tombolScan.addEventListener('click', function() {
        //     if (mediaHP.matches) modal.show();
        // });
        tombolScan.addEventListener('click', function() {
            modal.show();
        });

        modalElement.addEventListener('shown.bs.modal', mulaiKamera);
        modalElement.addEventListener('hidden.bs.modal', hentikanKamera);

        // mediaHP.addEventListener('change', aturTombolScan);
        // aturTombolScan();

        tombolAmbil.addEventListener('click', async function() {
            if (sedangUpload) return;

            if (!stream || !video.videoWidth) {
                status.textContent = 'Tunggu sampai kamera siap.';
                return;
            }

            try {
                canvas.width = video.videoWidth;
                canvas.height = video.videoHeight;

                canvas.getContext('2d').drawImage(
                    video,
                    0,
                    0,
                    canvas.width,
                    canvas.height
                );

                // Ubah gambar kamera menjadi file JPEG.
                const blob = await new Promise((resolve, reject) => {
                    canvas.toBlob(
                        result => result ?
                        resolve(result) :
                        reject(new Error('Gambar gagal dibuat.')),
                        'image/jpeg',
                        0.85
                    );
                });

                const file = new File(
                    [blob],
                    'nota.jpg', {
                        type: 'image/jpeg'
                    }
                );

                hentikanKamera();

                sedangUpload = true;
                tombolAmbil.disabled = true;
                tombolUlang.disabled = true;
                tombolUlang.classList.remove('d-none');
                status.textContent = 'Mengunggah gambar ke Livewire...';

                // Upload sementara ke komponen Livewire, lalu jalankan Prism.
                $wire.upload(
                    'fotoNota',
                    file,
                    () => {
                        status.textContent = 'Gambar diterima. Prism sedang memproses nota...';

                        $wire.scanNota()
                            .then(() => {
                                status.textContent =
                                    'Pemrosesan selesai. Periksa nama, harga, kategori, dan tanggal.';
                            })
                            .catch(error => {
                                status.textContent =
                                    'Pemrosesan gagal. Periksa pesan kesalahan pada formulir.';
                                console.error(error);
                            })
                            .finally(() => {
                                sedangUpload = false;
                                tombolUlang.disabled = false;
                            });
                    },
                    error => {
                        sedangUpload = false;
                        tombolAmbil.disabled = false;
                        tombolUlang.disabled = false;

                        status.textContent =
                            'Upload gambar gagal. Periksa koneksi lalu coba kembali.';

                        console.error(error);
                    },
                    event => {
                        status.textContent =
                            'Mengunggah gambar: ' +
                            event.detail.progress + '%';
                    }
                );
            } catch (error) {
                sedangUpload = false;
                tombolAmbil.disabled = false;

                status.textContent =
                    error.message || 'Gagal mengambil gambar nota.';

                console.error(error);
            }
        });

        tombolUlang.addEventListener('click', async function() {
            if (sedangUpload) return;

            hentikanKamera();

            tombolAmbil.disabled = true;
            tombolUlang.disabled = true;

            try {
                await $wire.resetScan();

                await mulaiKamera();
            } finally {
                tombolUlang.disabled = false;
            }
        });
    </script>
    <?php
        $__output = ob_get_clean();

        \Livewire\store($this)->push('scripts', $__output, $__scriptKey)
    ?>
<?php /**PATH D:\FOLDER-KULIAH\WEB-LOMAB\sistemmanajementkeuanganpribadi\resources\views/livewire/pengeluaran/scannota.blade.php ENDPATH**/ ?>