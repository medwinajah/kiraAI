
<?php $__env->startSection('title', 'Pengeluaran'); ?>
<?php $__env->startSection('link_css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/MenuList/pengeluaran.css','resources/js/pengeluaran/pengeluaranImportExcel.js']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session()->has('success')): ?>
    <section class="mb-3 p-3 rounded-4 bg-success text-white small fw-medium shadow-sm"
             role="alert">
        <i class="bi bi-check-circle-fill me-1"></i>
        <?php echo e(session('success')); ?>

    </section>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session()->has('error')): ?>
    <section class="mb-3 p-3 rounded-4 bg-danger text-white small fw-medium shadow-sm"
             role="alert">
        <i class="bi bi-exclamation-triangle-fill me-1"></i>
        <?php echo e(session('error')); ?>

    </section>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>


    <section class="d-flex align-items-center justify-content-between
                flex-wrap gap-3 py-3 border rounded-4 shadow-sm px-4"
    style="background: #fff; border-color: #e5ece6 !important;">

    <div class="py-2">
        <h3 class="fw-bold mb-2">
            Kelola <span class="title_pengeluaran">Pengeluaran Anda</span>
        </h3>

        <p class="small text-secondary mb-0">
            Catat setiap pengeluaran yang keluar pada halaman ini!
        </p>
    </div>

    
    <div class="d-flex flex-row flex-wrap gap-2 py-2 align-items-center"
        style="flex-shrink: 0;">

        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('pengeluaran.scannota');

$__keyOuter = $__key ?? null;

$__key = null;
$__componentSlots = [];

$__key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-1220575365-0', $__key);

$__html = app('livewire')->mount($__name, $__params, $__key, $__componentSlots);

echo $__html;

unset($__html);
unset($__key);
$__key = $__keyOuter;
unset($__keyOuter);
unset($__name);
unset($__params);
unset($__componentSlots);
unset($__split);
?>

        <a href="<?php echo e(route('pengeluaran.create')); ?>"
            wire:navigate
            class="btn btn-success border fw-semibold shadow-sm text-white
                   rounded-3 d-inline-flex align-items-center justify-content-center gap-2 py-3 rounded-4"
            style="white-space: nowrap;">

            <i class="fa-solid fa-circle-plus"></i>
            <span>Pengeluaran</span>

        </a>

    </div>
</section>






<section class="expense-import-card mt-4 mb-4">

    <div class="expense-import-header">
        <div class="expense-import-icon">
            <i class="fa-solid fa-file-excel"></i>
        </div>

        <div class="flex-grow-1">
            <span class="expense-import-eyebrow">
                IMPORT DATA PENGELUARAN
            </span>

            <h4>Upload Pengeluaran dari Excel</h4>

            <p>
                Impor banyak transaksi sekaligus. Periksa data terlebih
                dahulu sebelum menyimpannya ke database.
            </p>
        </div>
    </div>

    
    <form
        action="<?php echo e(route('pengeluaran.import.preview')); ?>"
        method="POST"
        enctype="multipart/form-data"
        class="expense-import-form"
    >
        <?php echo csrf_field(); ?>

        <label
            for="expense-excel-file"
            class="expense-import-dropzone"
            data-expense-dropzone
        >
            <input
                type="file"
                id="expense-excel-file"
                name="excel_file"
                class="expense-import-input"
                accept=".xlsx,.xls,.csv"
                data-expense-file-input
                required
            >

            <span class="expense-import-upload-icon">
                <i class="fa-solid fa-cloud-arrow-up"></i>
            </span>

            <strong>Tarik dan lepaskan file Excel di sini</strong>

            <span class="expense-import-description">
                atau klik area ini untuk memilih file dari perangkatmu.
            </span>

            <span class="expense-import-formats">
                XLSX, XLS, atau CSV · Maksimal 5 MB
            </span>

            <span
                class="expense-import-filename"
                data-expense-filename
                aria-live="polite"
            >
                Belum ada file yang dipilih
            </span>
        </label>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['excel_file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="expense-import-validation">
                <i class="fa-solid fa-circle-exclamation"></i>
                <?php echo e($message); ?>

            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <div class="expense-import-actions">

            <a
                href="<?php echo e(route('pengeluaran.import.template')); ?>"
                class="expense-import-template"
            >
                <i class="fa-solid fa-download"></i>
                Unduh Template Pengeluaran
            </a>

            <button
                type="submit"
                class="expense-import-submit"
            >
                <i class="fa-solid fa-eye"></i>
                Baca dan Preview Data
            </button>

        </div>
    </form>

    <div class="expense-import-note">
        <i class="fa-solid fa-shield-halved"></i>

        <span>
            Fitur ini hanya mengimpor pengeluaran. Kategori harus sesuai
            dengan kategori pada akunmu. Data baru disimpan setelah
            dikonfirmasi.
        </span>
    </div>

</section>






<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($importPreview)): ?>

    <?php
        $validRows = collect($importPreview)
            ->filter(fn ($row) => empty($row['errors']))
            ->count();

        $invalidRows = count($importPreview) - $validRows;
    ?>

    <section class="expense-import-preview mt-4 mb-4">

        
        <div class="expense-preview-header">

            <div class="expense-preview-heading">
                <span class="expense-import-eyebrow">
                    PEMERIKSAAN DATA
                </span>

                <h4>Preview Pengeluaran</h4>

                <p>
                    Periksa data transaksi dan perbaiki baris yang
                    belum valid sebelum menyimpan.
                </p>
            </div>

            <div class="expense-preview-header-actions">

                <span class="expense-preview-count">
                    <?php echo e(count($importPreview)); ?> baris
                </span>

                <form
                    action="<?php echo e(route('pengeluaran.import.cancel')); ?>"
                    method="POST"
                    onsubmit="return confirm('Batalkan preview pengeluaran ini? Preview sementara akan dihapus dan transaksi belum disimpan.');"
                >
                    <?php echo csrf_field(); ?>

                    <button
                        type="submit"
                        class="expense-preview-close"
                        title="Batalkan preview"
                        aria-label="Batalkan preview pengeluaran"
                    >
                        <i class="fa-solid fa-xmark"></i>
                    </button>
                </form>

            </div>

        </div>

        
        <div class="expense-import-summary">

            <div class="expense-import-summary-item">
                <span>Baris valid</span>
                <strong class="text-success"><?php echo e($validRows); ?></strong>
            </div>

            <div class="expense-import-summary-item">
                <span>Perlu diperbaiki</span>

                <strong class="<?php echo e($invalidRows > 0 ? 'text-danger' : 'text-success'); ?>">
                    <?php echo e($invalidRows); ?>

                </strong>
            </div>

        </div>

        
        <div class="table-responsive expense-preview-table-wrap">

            <table class="table align-middle mb-0 expense-preview-table">

                <thead>
                    <tr>
                        <th>Baris</th>
                        <th>Tanggal</th>
                        <th>Transaksi</th>
                        <th>Kategori</th>
                        <th class="text-end">Nominal</th>
                        <th>Status</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $importPreview; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>

                        <tr>
                            <td><?php echo e($row['row_number']); ?></td>

                            <td class="text-nowrap">
                                <?php echo e($row['tanggal'] ?? '—'); ?>

                            </td>

                            <td>
                                <strong>
                                    <?php echo e($row['label'] ?: '—'); ?>

                                </strong>

                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($row['deskripsi'])): ?>
                                    <small class="expense-preview-description">
                                        <?php echo e($row['deskripsi']); ?>

                                    </small>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </td>

                            <td>
                                <?php echo e($row['kategori'] ?: '—'); ?>

                            </td>

                            <td class="text-end text-nowrap">
                                <?php echo e($row['jumlah'] !== null
                                    ? 'Rp ' . number_format($row['jumlah'], 0, ',', '.')
                                    : '—'); ?>

                            </td>

                            <td>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(empty($row['errors'])): ?>
                                    <span class="expense-import-status expense-import-status--valid">
                                        <i class="fa-solid fa-circle-check"></i>
                                        Valid
                                    </span>
                                <?php else: ?>
                                    <span class="expense-import-status expense-import-status--invalid">
                                        <i class="fa-solid fa-circle-exclamation"></i>
                                        Periksa
                                    </span>

                                    <ul class="expense-preview-errors">
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $row['errors']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                    </ul>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </td>
                        </tr>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </tbody>

            </table>

        </div>

        
        <div class="expense-import-confirm-area">

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($importHasErrors): ?>

                <p class="expense-import-confirm-warning">
                    <i class="fa-solid fa-triangle-exclamation"></i>

                    Masih ada data yang tidak valid. Tutup preview,
                    perbaiki file Excel, lalu unggah ulang.
                </p>

            <?php else: ?>

                <p class="expense-import-confirm-help">
                    Semua baris valid. Pastikan nominal, tanggal,
                    dan kategori sudah benar sebelum melanjutkan.
                </p>

                <form
                    action="<?php echo e(route('pengeluaran.import.confirm')); ?>"
                    method="POST"
                    onsubmit="return confirm('Simpan seluruh transaksi pengeluaran dari file Excel ini?');"
                >
                    <?php echo csrf_field(); ?>

                    <button
                        type="submit"
                        class="expense-import-submit"
                    >
                        <i class="fa-solid fa-database"></i>
                        Konfirmasi dan Simpan Pengeluaran
                    </button>
                </form>

            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        </div>

    </section>

<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>


    <div class="px-2">
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('pengeluaran.komponenindexis');

$__keyOuter = $__key ?? null;

$__key = null;
$__componentSlots = [];

$__key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-1220575365-1', $__key);

$__html = app('livewire')->mount($__name, $__params, $__key, $__componentSlots);

echo $__html;

unset($__html);
unset($__key);
$__key = $__keyOuter;
unset($__keyOuter);
unset($__name);
unset($__params);
unset($__componentSlots);
unset($__split);
?>
    </div>

    
    <?php echo $__env->make('pages.Pengeluaran.partials.modalKamereScan', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\FOLDER-KULIAH\WEB-LOMAB\sistemmanajementkeuanganpribadi\resources\views/pages/Pengeluaran/index.blade.php ENDPATH**/ ?>