<div class="income-page">

    
    <section class="card border-0 shadow-sm rounded-4 mb-3 income-filter-card">
        <div class="card-body p-3 p-lg-4">

            <div class="d-flex align-items-start justify-content-between flex-wrap gap-2 mb-4">
                <div>
                    <span class="badge rounded-pill bg-success-subtle text-success mb-2 px-3 py-2">
                        <i class="fa-solid fa-filter me-1"></i>
                        Filter Transaksi
                    </span>

                    <h4 class="fw-bold mb-1">
                        Filter Data <span class="text-success">Pemasukan</span>
                    </h4>

                    <p class="text-secondary small mb-0">
                        Temukan data pemasukan berdasarkan tanggal atau kata kunci.
                    </p>
                </div>

                <div class="d-flex align-items-center gap-2 text-success small fw-semibold">
                    <i class="fa-solid fa-wallet"></i>
                    Data Pemasukan
                </div>
            </div>

            <div class="row g-3 align-items-end">

                
                <div class="col-lg-6">
                    <div class="row g-2">

                        <div class="col-sm-6">
                            <label for="tanggal_mulai"
                                   class="form-label small fw-semibold">
                                Tanggal Awal
                            </label>

                            <div class="input-group border rounded-3 overflow-hidden bg-white">
                                <span class="input-group-text bg-white border-0 text-success">
                                    <i class="fa-solid fa-calendar-days"></i>
                                </span>

                                <input
                                    type="date"
                                    id="tanggal_mulai"
                                    wire:model.live.debounce.300ms="tanggal_mulai"
                                    class="form-control border-0 shadow-none py-2"
                                >
                            </div>
                        </div>

                        <div class="col-sm-6">
                            <label for="tanggal_selesai"
                                   class="form-label small fw-semibold">
                                Tanggal Akhir
                            </label>

                            <div class="input-group border rounded-3 overflow-hidden bg-white">
                                <span class="input-group-text bg-white border-0 text-success">
                                    <i class="fa-solid fa-calendar-check"></i>
                                </span>

                                <input
                                    type="date"
                                    id="tanggal_selesai"
                                    wire:model.live.debounce.300ms="tanggal_selesai"
                                    class="form-control border-0 shadow-none py-2"
                                >
                            </div>
                        </div>

                    </div>
                </div>

                
                <div class="col-lg-5 col-md-9">
                    <label for="search_pemasukan"
                           class="form-label small fw-semibold">
                        Cari Pemasukan
                    </label>

                    <div class="input-group border rounded-3 overflow-hidden bg-white">
                        <span class="input-group-text bg-white border-0 text-success">
                            <i class="fa-solid fa-magnifying-glass"></i>
                        </span>

                        <input
                            type="search"
                            id="search_pemasukan"
                            wire:model.live.debounce.300ms="search"
                            placeholder="Cari label atau deskripsi..."
                            class="form-control border-0 shadow-none py-2"
                        >
                    </div>
                </div>

                
                <div class="col-lg-1 col-md-3">
                    <label class="form-label small fw-semibold">
                        Reset
                    </label>

                    <button
                        type="button"
                        wire:click="resetProperty"
                        class="btn btn-outline-danger rounded-3 w-100 py-2"
                        title="Reset semua filter"
                        aria-label="Reset filter pemasukan"
                    >
                        <i class="fa-solid fa-rotate-left"></i>
                    </button>
                </div>

            </div>
        </div>
    </section>


    
    <section class="card border-0 shadow-sm rounded-4 mb-3">
        <div class="card-body p-3">
            <div class="d-flex align-items-center justify-content-between
                        flex-wrap gap-2">

                <div class="d-flex align-items-center gap-3">
                    <div class="rounded-3 bg-success-subtle text-success
                                d-flex align-items-center justify-content-center"
                         style="width: 42px; height: 42px; flex-shrink: 0;">
                        <i class="fa-solid fa-list-ul"></i>
                    </div>

                    <div>
                        <h6 class="fw-bold mb-1">Daftar Pemasukan</h6>

                        <p class="text-secondary small mb-0">
                            Menampilkan
                            <span class="fw-semibold text-dark">
                                <?php echo e($pemasukan->firstItem() ?? 0); ?>

                            </span>
                            sampai
                            <span class="fw-semibold text-dark">
                                <?php echo e($pemasukan->lastItem() ?? 0); ?>

                            </span>
                            dari
                            <span class="fw-semibold text-dark">
                                <?php echo e($pemasukan->total()); ?>

                            </span>
                            data.
                        </p>
                    </div>
                </div>

                <span class="badge rounded-pill bg-success-subtle text-success px-3 py-2">
                    <i class="fa-solid fa-database me-1"></i>
                    <?php echo e($pemasukan->total()); ?> Data
                </span>

            </div>
        </div>
    </section>


    
    <section class="card border-0 shadow-sm rounded-4 overflow-hidden income-table-card">

        
        <div class="card-header bg-white border-0 px-3 px-lg-4 pt-4 pb-3">
            <div class="d-flex align-items-center gap-3">
                <div class="rounded-3 bg-success-subtle text-success
                            d-flex align-items-center justify-content-center"
                     style="width: 46px; height: 46px; flex-shrink: 0;">
                    <i class="fa-solid fa-money-bill-trend-up fs-5"></i>
                </div>

                <div>
                    <h5 class="fw-bold mb-1">Riwayat Pemasukan</h5>
                    <p class="text-secondary small mb-0">
                        Kelola dan pantau transaksi pemasukanmu.
                    </p>
                </div>
            </div>
        </div>

        
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0 income-table"
                   style="min-width: 1050px;">

                <thead class="table-light">
                    <tr>
                        <th class="text-center text-success small fw-bold py-3 px-3"
                            style="width: 65px;">
                            No.
                        </th>

                        <th class="text-success small fw-bold py-3 px-3"
                            style="min-width: 180px;">
                            LABEL
                        </th>

                        <th class="text-success small fw-bold py-3 px-3"
                            style="min-width: 150px;">
                            KATEGORI
                        </th>

                        <th class="text-success small fw-bold py-3 px-3"
                            style="min-width: 180px;">
                            JUMLAH
                        </th>

                        <th class="text-success small fw-bold py-3 px-3"
                            style="min-width: 135px;">
                            TANGGAL
                        </th>

                        <th class="text-success small fw-bold py-3 px-3"
                            style="min-width: 210px;">
                            DESKRIPSI
                        </th>

                        <th class="text-center text-success small fw-bold py-3 px-3"
                            style="width: 115px;">
                            AKSI
                        </th>
                    </tr>
                </thead>

                <tbody>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $pemasukan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>

                        <tr <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'pemasukan-'.e($data->id).''; ?>wire:key="pemasukan-<?php echo e($data->id); ?>">

                            
                            <td class="text-center px-3 py-3">
                                <span class="text-secondary small fw-semibold">
                                    <?php echo e(($pemasukan->currentPage() - 1) * $pemasukan->perPage() + $loop->iteration); ?>

                                </span>
                            </td>

                            
                            <td class="px-3 py-3">
                                <div class="fw-semibold text-dark">
                                    <?php echo e($data->label); ?>

                                </div>
                            </td>

                            
                            <td class="px-3 py-3">
                                <span class="badge bg-success-subtle text-success
                                             border border-success-subtle
                                             rounded-pill px-3 py-2 fw-semibold">
                                    <i class="fa-solid fa-tag me-1"></i>
                                    <?php echo e($data->Kategori?->nama_kategori ?? 'Tanpa kategori'); ?>

                                </span>
                            </td>

                            
                            <td class="px-3 py-3">
                                <div class="fw-bold text-success">
                                    Rp<?php echo e(number_format(
                                        (float) $data->jumlah_pemasukan,
                                        0,
                                        ',',
                                        '.'
                                    )); ?>

                                </div>

                                <div class="text-secondary small mt-1">
                                    <i class="fa-solid fa-arrow-trend-up me-1"></i>
                                    <?php echo e($data->sumber_pemasukan ?: 'Sumber tidak diisi'); ?>

                                </div>
                            </td>

                            
                            <td class="px-3 py-3">
                                <div class="d-flex align-items-center gap-2 text-secondary small">
                                    <i class="fa-regular fa-calendar text-success"></i>

                                    <span class="text-nowrap">
                                        <?php echo e($data->tanggal_pemasukan?->format('d-m-Y') ?? '—'); ?>

                                    </span>
                                </div>
                            </td>

                            
                            <td class="px-3 py-3">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($data->deskripsi_pemasukan): ?>
                                    <span
                                        class="d-inline-block text-secondary small text-truncate"
                                        style="max-width: 190px;"
                                        title="<?php echo e($data->deskripsi_pemasukan); ?>"
                                    >
                                        <?php echo e($data->deskripsi_pemasukan); ?>

                                    </span>
                                <?php else: ?>
                                    <span class="text-secondary small fst-italic">
                                        Tidak ada deskripsi
                                    </span>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </td>

                            
                            <td class="px-3 py-3">
                                <div class="d-flex justify-content-center align-items-center gap-2">

                                    
                                    <a
                                        href="<?php echo e(route('pemasukan.edit', $data->id)); ?>"
                                        class="btn btn-sm btn-success rounded-3
                                               d-inline-flex align-items-center justify-content-center"
                                        style="width: 35px; height: 35px;"
                                        title="Edit pemasukan"
                                        aria-label="Edit pemasukan <?php echo e($data->label); ?>"
                                    >
                                        <i class="fa-solid fa-pen-to-square"></i>
                                    </a>

                                    
                                    <button
                                        type="button"
                                        class="btn btn-sm btn-danger rounded-3
                                               d-inline-flex align-items-center justify-content-center"
                                        style="width: 35px; height: 35px;"
                                        data-bs-toggle="modal"
                                        data-bs-target="#deleteusers<?php echo e($data->id); ?>"
                                        title="Hapus pemasukan"
                                        aria-label="Hapus pemasukan <?php echo e($data->label); ?>"
                                    >
                                        <i class="fa-solid fa-trash-can"></i>
                                    </button>

                                </div>
                            </td>

                        </tr>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

                        
                        <tr>
                            <td colspan="7" class="text-center py-5 px-3">

                                <div class="d-flex flex-column align-items-center">

                                    <div class="rounded-circle bg-success-subtle text-success
                                                d-flex align-items-center justify-content-center mb-3"
                                         style="width: 70px; height: 70px;">
                                        <i class="fa-solid fa-folder-open fa-2x"></i>
                                    </div>

                                    <h6 class="fw-bold mb-2">
                                        <?php echo e($pemasukan->total() > 0
                                            ? 'Data Tidak Ditemukan'
                                            : 'Belum Ada Data Pemasukan'); ?>

                                    </h6>

                                    <p class="text-secondary small mb-0">
                                        <?php echo e($pemasukan->total() > 0
                                            ? 'Coba ubah kata kunci pencarian atau rentang tanggal.'
                                            : 'Data pemasukan yang kamu tambahkan akan ditampilkan di sini.'); ?>

                                    </p>

                                </div>

                            </td>
                        </tr>

                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </tbody>

            </table>
        </div>

        
        <div class="card-footer bg-white border-top px-3 px-lg-4 py-3">
            <div class="d-flex justify-content-center justify-content-md-end">
                <?php echo e($pemasukan->links()); ?>

            </div>
        </div>

    </section>

    
    <?php echo $__env->make('pemasukan.partials.modalhapus', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</div><?php /**PATH D:\FOLDER-KULIAH\WEB-LOMAB\sistemmanajementkeuanganpribadi\resources\views/livewire/pemasukan/komponenindexis.blade.php ENDPATH**/ ?>