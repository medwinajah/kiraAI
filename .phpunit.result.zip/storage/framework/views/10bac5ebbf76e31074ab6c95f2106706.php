
<?php $__env->startSection('title', 'Pengeluaran'); ?>
<?php $__env->startSection('link_css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/MenuList/pengeluaran.css']); ?>
      <?php echo app('Illuminate\Foundation\Vite')(['resources/css/MenuList/pengeluaranEdit.css']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  
    <div class="container row rounded-3 mt-1 py-3 align-items-center w-100 m-auto">
        <section class="col-lg-8 col-12 border mx-lg-auto py-3 rounded-4 shadow">
            <section class="border-bottom mb-3">
                <a href="<?php echo e(route('pengeluaran.index')); ?>" wire:navigate class="text-decoration-none">
                <button class="btn btn-outline-secondary small fw-semibold rounded-4 mb-3"><i class="fa-solid fa-backward"></i> Kembali</button></a>
            </section>
            <h4 class="text-center fw-bold py-3 bg-tambah shadow-sm border rounded-4 text-white mb-4">Edit Catatan pengeluaran</h4>

            <div class="px-2">
                <form action="<?php echo e(route('pengeluaran.update',$pengeluaran->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="row g-2">
                        
                    <section class="mb-1 col-lg-12 col-sm-12">
                        <label for="label_pengeluaran" class="form-label small fw-semibold">Label pengeluaran <sup class="text-danger fs-6">*</sup></label>
                        <div class=" border <?php $__errorArgs = ['label'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            border-danger
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> rounded-3 p-0 d-flex align-items-center">
                        <span class="border-0 d-flex gap-2 p-2">
                             <i class="fa-solid fa-bookmark"></i>         
                        </span>
                        <input type="text" class="form-control p-2 border-0 w-100 focus-ring focus-ring-light"  value="<?php echo e($pengeluaran->label); ?>" name="label" placeholder="Label pengeluaran" id="label_pengeluaran">

                        </div>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['label'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="small text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </section>

                     
                    <section class="mb-1 col-lg-6 col-sm-12">
                        <label for="kategori_pengeluaran" class="form-label small fw-semibold">Kategori pengeluaran <sup class="text-danger fs-6">*</sup></label>
                        <div class="border rounded-3 p-0 d-flex gap-2 <?php $__errorArgs = ['kategori'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            border-danger
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <span class="border-0 d-flex align-items-center p-2 ">
                             <i class="fa-solid fa-bookmark"></i>
                        </span>
                        <select name="kategori" id="kategori" class="form-select w-100 p-2 border-0">
                                <option value="" class="form-select">Pilih Kategori</option>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $kategori_pengeluaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <option value="<?php echo e($kategori->id); ?>" <?php echo e($pengeluaran->id_kategori == $kategori->id?'selected':''); ?>><?php echo e($kategori->nama_ketegori); ?></option>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                <option value="">$Kategori Masih Kosong</option>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                           </select>
                        </div>
                         <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['kategori'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="small text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </section>

                     
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('pengeluaran.partials.formnumber',['jumlah_pengeluarans'=>$pengeluaran->jumlah_pengeluaran]);

$__keyOuter = $__key ?? null;

$__key = null;
$__componentSlots = [];

$__key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-2998747771-0', $__key);

$__html = app('livewire')->mount($__name, $__params, $__key, $__componentSlots);

echo $__html;

unset($__html);
unset($__key);
$__key = $__keyOuter;
unset($__keyOuter);
unset($__name);
unset($__params);
unset($__componentSlots);
unset($__split);
?>

                     

                    
                    <section class="mb-1 col-lg-6 col-sm-12">
                        <label for="tanggal_pengeluaran" class="form-label small fw-semibold">Tanggal pengeluaran <sup class="text-danger fs-6">*</sup></label>
                        <div class=" border <?php $__errorArgs = ['tanggal_pengeluaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            border-danger
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> rounded-3 p-0 d-flex align-items-center">
                        <span class="border-0 d-flex gap-2 p-2">
                             <i class="fa-solid fa-bookmark"></i>         
                        </span>
                        <input type="date" name="tanggal_pengeluaran" 
                        value=<?php echo e($pengeluaran->tanggal_pengeluaran->format('Y-m-d')); ?>

                        class="form-control p-2 border-0 w-100 focus-ring focus-ring-light"  id="tanggal_pengeluaran">
                        </div>
                         <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['tanggal_pengeluaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="small text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </section>

                    
                    <section class="mb-1 col-lg-12 col-sm-12">
                        <label for="deskripsi_pengeluaran" class="form-label small fw-semibold">Deskripsi pengeluaran</label>
                        <div class=" border <?php $__errorArgs = ['deskripsi_pengeluaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            border-danger
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> rounded-3 p-0 d-flex align-items-center">
                        <textarea name="deskripsi_pengeluaran" id="" cols="30" rows="2" placeholder="Catat deskripsi pengeluaran" class="form-control"><?php echo e($pengeluaran->deskripsi_pengeluaran); ?></textarea>
                        </div>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['deskripsi_pengeluaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="small text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </section>

                    
                    <section class="mb-1 col-lg-12 col-sm-12 mt-3">
                        <div class="d-flex justify-content-between align-items-center gap-2"> 
                            <button class="btn btn-outline-danger rounded w-50 py-2 rounded-4 fw-semibold" type="reset"> <i class="fa-solid fa-rotate-left"></i> Batal</button>
                             <button type="submit" class="btn btn-tambah rounded w-50 py-2 rounded-4 fw-semibold text-white" type="reset"> Edit <i class="fa-solid fa-wand-magic-sparkles"></i> </button>
                        </div>
                    </section>
                    </div>
                </form>
            </div>
        </section>
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\FOLDER-KULIAH\WEB-LOMAB\sistemmanajementkeuanganpribadi\resources\views/pages/Pengeluaran/edit.blade.php ENDPATH**/ ?>